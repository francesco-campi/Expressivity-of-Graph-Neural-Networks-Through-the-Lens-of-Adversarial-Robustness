import torch
import torch.nn as nn
import torch.nn.functional as F

import dgl
import numpy as np

"""
    Graph Transformer with edge features
    
"""
from .graph_transformer_layer import GraphTransformerLayer
from .mlp_readout_layer import MLPReadout

class SAN_NodeLPE(nn.Module):
    def __init__(self, 
        hidden_channels: int,  
        out_channels: int,
        num_layers: int,  
        pooling: str = 'add', 
        concat: bool = True,
        act: float = 1e-2, # gamma
        batch_norm: bool = False
        ):
        super().__init__()
        
        num_atom_type = 2
        num_bond_type = 2
        
        full_graph = True
        gamma = act
        
        LPE_layers = 3
        LPE_dim = 16
        LPE_n_heads = 4
        
        GT_layers = num_layers
        GT_hidden_dim = hidden_channels
        GT_out_dim = out_channels
        GT_n_heads = 8
        
        self.residual = concat
        self.readout = pooling
        in_feat_dropout = 0.0
        dropout = 0.0

        self.layer_norm = False
        self.batch_norm = batch_norm


        self.in_feat_dropout = nn.Dropout(in_feat_dropout)
        
        self.embedding_h = nn.Embedding(num_atom_type, GT_hidden_dim-LPE_dim)#Remove some embedding dimensions to make room for concatenating laplace encoding
        self.embedding_e = nn.Embedding(num_bond_type, GT_hidden_dim)
        self.linear_A = nn.Linear(2, LPE_dim)
        
        encoder_layer = nn.TransformerEncoderLayer(d_model=LPE_dim, nhead=LPE_n_heads)
        self.PE_Transformer = nn.TransformerEncoder(encoder_layer, num_layers=LPE_layers)
        
        self.layers = nn.ModuleList([ GraphTransformerLayer(gamma, GT_hidden_dim, GT_hidden_dim, GT_n_heads, full_graph, dropout, self.layer_norm, self.batch_norm, self.residual) for _ in range(GT_layers-1) ])
        
        self.layers.append(GraphTransformerLayer(gamma, GT_hidden_dim, GT_out_dim, GT_n_heads, full_graph, dropout, self.layer_norm, self.batch_norm, self.residual))
        self.MLP_layer = nn.Sequential(
                nn.Linear(GT_out_dim, GT_out_dim), 
                nn.ReLU(), 
                nn.Linear(GT_out_dim, 1)
            )#MLPReadout(GT_out_dim, 1)   # 1 out dim since regression problem        
        
        
    def forward(self, g):
        
        h = g.ndata['feat']
        e = g.edata['feat']

        EigVecs = g.ndata['EigVecs']
        #random flip
        # sign_flip = torch.rand(batch_EigVecs.size(1)).to(device)
        # sign_flip[sign_flip>=0.5] = 1.0; sign_flip[sign_flip<0.5] = -1.0
        EigVals = g.ndata['EigVals']
        # input embedding
        h = self.embedding_h(h)
        
        e = self.embedding_e(e)  
        
        PosEnc = torch.cat((EigVecs.unsqueeze(2), EigVals), dim=2).float() # (Num nodes) x (Num Eigenvectors) x 2
        empty_mask = torch.isnan(PosEnc) # (Num nodes) x (Num Eigenvectors) x 2
        
        PosEnc[empty_mask] = 0 # (Num nodes) x (Num Eigenvectors) x 2
        PosEnc = torch.transpose(PosEnc, 0 ,1).float() # (Num Eigenvectors) x (Num nodes) x 2
        PosEnc = self.linear_A(PosEnc) # (Num Eigenvectors) x (Num nodes) x PE_dim
        
        
        #1st Transformer: Learned PE
        PosEnc = self.PE_Transformer(src=PosEnc, src_key_padding_mask=empty_mask[:,:,0]) 
        
        #remove masked sequences
        PosEnc[torch.transpose(empty_mask, 0 ,1)[:,:,0]] = float('nan') 
        
        #Sum pooling
        PosEnc = torch.nansum(PosEnc, 0, keepdim=False)

        #Concatenate learned PE to input embedding
        h = torch.cat((h, PosEnc), 1)
        
        h = self.in_feat_dropout(h)
        
        # GNN
        for conv in self.layers:
            h, e = conv(g, h, e)
        #print(e)
        g.ndata['h'] = h
        
        if self.readout == "sum":
            hg = dgl.sum_nodes(g, 'h')
        elif self.readout == "max":
            hg = dgl.max_nodes(g, 'h')
        elif self.readout == "mean":
            hg = dgl.mean_nodes(g, 'h')
        else:
            hg = dgl.mean_nodes(g, 'h')  # default readout is mean nodes
        return self.MLP_layer(hg)